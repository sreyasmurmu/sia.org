import Link from "next/link"
import { Facebook, Instagram, Twitter, Youtube } from "lucide-react"

export default function Footer() {
  return (
    <footer className="w-full border-t bg-background">
      <div className="container flex flex-col gap-8 py-8 md:py-12">
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 md:grid-cols-4">
          <div className="flex flex-col gap-2">
            <h3 className="text-lg font-semibold">About SIA</h3>
            <Link href="/about" className="text-sm text-gray-600 hover:text-green-600">
              Our Mission
            </Link>
            <Link href="/about" className="text-sm text-gray-600 hover:text-green-600">
              Our Team
            </Link>
            <Link href="/about" className="text-sm text-gray-600 hover:text-green-600">
              History
            </Link>
          </div>
          <div className="flex flex-col gap-2">
            <h3 className="text-lg font-semibold">Resources</h3>
            <Link href="/resources" className="text-sm text-gray-600 hover:text-green-600">
              Learning Materials
            </Link>
            <Link href="/resources" className="text-sm text-gray-600 hover:text-green-600">
              Grammar Guides
            </Link>
            <Link href="/translate" className="text-sm text-gray-600 hover:text-green-600">
              Translation Tool
            </Link>
          </div>
          <div className="flex flex-col gap-2">
            <h3 className="text-lg font-semibold">Community</h3>
            <Link href="/events" className="text-sm text-gray-600 hover:text-green-600">
              Events
            </Link>
            <Link href="/get-involved" className="text-sm text-gray-600 hover:text-green-600">
              Get Involved
            </Link>
            <Link href="/blog" className="text-sm text-gray-600 hover:text-green-600">
              Blog
            </Link>
          </div>
          <div className="flex flex-col gap-2">
            <h3 className="text-lg font-semibold">Contact</h3>
            <Link href="/contact" className="text-sm text-gray-600 hover:text-green-600">
              Contact Us
            </Link>
            <Link href="/support" className="text-sm text-gray-600 hover:text-green-600">
              Support
            </Link>
            <Link href="/faq" className="text-sm text-gray-600 hover:text-green-600">
              FAQ
            </Link>
          </div>
        </div>
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex gap-4">
            <Link href="#" className="text-gray-600 hover:text-green-600">
              <Facebook className="h-5 w-5" />
              <span className="sr-only">Facebook</span>
            </Link>
            <Link href="#" className="text-gray-600 hover:text-green-600">
              <Twitter className="h-5 w-5" />
              <span className="sr-only">Twitter</span>
            </Link>
            <Link href="#" className="text-gray-600 hover:text-green-600">
              <Instagram className="h-5 w-5" />
              <span className="sr-only">Instagram</span>
            </Link>
            <Link href="#" className="text-gray-600 hover:text-green-600">
              <Youtube className="h-5 w-5" />
              <span className="sr-only">YouTube</span>
            </Link>
          </div>
          <p className="text-sm text-gray-600">
            © {new Date().getFullYear()} Santali International Association. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  )
}
