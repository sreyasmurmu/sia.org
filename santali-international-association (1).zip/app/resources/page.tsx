import Link from "next/link"
import { ArrowRight, BookOpen, FileText, Headphones, Video } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function ResourcesPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-br from-green-600 to-green-700 text-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">Learning Resources</h1>
              <p className="max-w-[900px] text-white/90 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Comprehensive materials to help you learn and master the Santali language.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Resources Tabs Section */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <Tabs defaultValue="beginners" className="w-full">
            <div className="flex justify-center mb-8">
              <TabsList className="grid w-full max-w-md grid-cols-3">
                <TabsTrigger value="beginners">Beginners</TabsTrigger>
                <TabsTrigger value="intermediate">Intermediate</TabsTrigger>
                <TabsTrigger value="advanced">Advanced</TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="beginners" className="space-y-8">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-gray-900">Pronunciation Guide</CardTitle>
                    <CardDescription>Learn the basics of Santali pronunciation</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2 mb-4">
                      <Headphones className="h-5 w-5 text-green-600" />
                      <span className="text-sm text-gray-600">Audio lessons included</span>
                    </div>
                    <p className="text-sm text-gray-600">
                      Master the sounds of Santali with our comprehensive pronunciation guide, complete with audio
                      examples.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full bg-transparent">
                      Start Learning
                    </Button>
                  </CardFooter>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-gray-900">Basic Vocabulary</CardTitle>
                    <CardDescription>Essential words for beginners</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2 mb-4">
                      <FileText className="h-5 w-5 text-green-600" />
                      <span className="text-sm text-gray-600">500+ words with examples</span>
                    </div>
                    <p className="text-sm text-gray-600">
                      Build your Santali vocabulary with common words and phrases used in everyday conversations.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full bg-transparent">
                      View Vocabulary
                    </Button>
                  </CardFooter>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-gray-900">Simple Conversations</CardTitle>
                    <CardDescription>Practice basic dialogues</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2 mb-4">
                      <Video className="h-5 w-5 text-green-600" />
                      <span className="text-sm text-gray-600">Video demonstrations</span>
                    </div>
                    <p className="text-sm text-gray-600">
                      Learn how to introduce yourself and have simple conversations in Santali.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full bg-transparent">
                      Practice Now
                    </Button>
                  </CardFooter>
                </Card>
              </div>

              <div className="flex justify-center">
                <Link href="/resources/beginners">
                  <Button className="bg-green-600 hover:bg-green-700">
                    View All Beginner Resources <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </TabsContent>

            <TabsContent value="intermediate" className="space-y-8">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-gray-900">Grammar Structures</CardTitle>
                    <CardDescription>Intermediate grammar lessons</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2 mb-4">
                      <BookOpen className="h-5 w-5 text-green-600" />
                      <span className="text-sm text-gray-600">Comprehensive guide</span>
                    </div>
                    <p className="text-sm text-gray-600">
                      Deepen your understanding of Santali grammar with more complex sentence structures.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full bg-transparent">
                      Study Grammar
                    </Button>
                  </CardFooter>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-gray-900">Reading Passages</CardTitle>
                    <CardDescription>Intermediate reading practice</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2 mb-4">
                      <FileText className="h-5 w-5 text-green-600" />
                      <span className="text-sm text-gray-600">Cultural stories and texts</span>
                    </div>
                    <p className="text-sm text-gray-600">
                      Improve your reading skills with authentic Santali texts and stories.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full bg-transparent">
                      Start Reading
                    </Button>
                  </CardFooter>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-gray-900">Listening Exercises</CardTitle>
                    <CardDescription>Improve your listening skills</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2 mb-4">
                      <Headphones className="h-5 w-5 text-green-600" />
                      <span className="text-sm text-gray-600">Audio recordings</span>
                    </div>
                    <p className="text-sm text-gray-600">
                      Train your ear with authentic Santali conversations and narratives.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full bg-transparent">
                      Listen Now
                    </Button>
                  </CardFooter>
                </Card>
              </div>

              <div className="flex justify-center">
                <Link href="/resources/intermediate">
                  <Button className="bg-green-600 hover:bg-green-700">
                    View All Intermediate Resources <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </TabsContent>

            <TabsContent value="advanced" className="space-y-8">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-gray-900">Advanced Literature</CardTitle>
                    <CardDescription>Classic and modern Santali texts</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2 mb-4">
                      <BookOpen className="h-5 w-5 text-green-600" />
                      <span className="text-sm text-gray-600">Literary analysis</span>
                    </div>
                    <p className="text-sm text-gray-600">
                      Explore the rich literary tradition of Santali through classic and contemporary works.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full bg-transparent">
                      Explore Literature
                    </Button>
                  </CardFooter>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-gray-900">Cultural Context</CardTitle>
                    <CardDescription>Deep dive into Santali culture</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2 mb-4">
                      <Video className="h-5 w-5 text-green-600" />
                      <span className="text-sm text-gray-600">Documentaries and interviews</span>
                    </div>
                    <p className="text-sm text-gray-600">
                      Understand the cultural context behind the language with in-depth resources.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full bg-transparent">
                      Learn More
                    </Button>
                  </CardFooter>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-gray-900">Dialectal Variations</CardTitle>
                    <CardDescription>Regional differences in Santali</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2 mb-4">
                      <Headphones className="h-5 w-5 text-green-600" />
                      <span className="text-sm text-gray-600">Audio comparisons</span>
                    </div>
                    <p className="text-sm text-gray-600">
                      Explore the different dialects and regional variations of the Santali language.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full bg-transparent">
                      Study Dialects
                    </Button>
                  </CardFooter>
                </Card>
              </div>

              <div className="flex justify-center">
                <Link href="/resources/advanced">
                  <Button className="bg-green-600 hover:bg-green-700">
                    View All Advanced Resources <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>
    </div>
  )
}
