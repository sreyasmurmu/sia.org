import Link from "next/link"
import { BookOpen, Gift, Handshake, Languages, Pencil, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function GetInvolvedPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-br from-green-600 to-green-700 text-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">Get Involved</h1>
              <p className="max-w-[900px] text-white/90 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Join our global movement to preserve and promote the Santali language and culture.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Ways to Get Involved Section */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl text-gray-900">Ways to Get Involved</h2>
              <p className="max-w-[900px] text-gray-600 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                There are many ways you can contribute to our mission, regardless of your background or location.
              </p>
            </div>
          </div>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <div className="rounded-full bg-green-100 p-3 w-12 h-12 flex items-center justify-center mb-4">
                  <Languages className="h-6 w-6 text-green-600" />
                </div>
                <CardTitle className="text-gray-900">Become a Translator</CardTitle>
                <CardDescription>Help translate resources between Santali and other languages</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  Use your language skills to help translate educational materials, website content, and other
                  resources.
                </p>
              </CardContent>
              <CardFooter>
                <Link href="/get-involved/translator" className="w-full">
                  <Button variant="outline" className="w-full bg-transparent">
                    Learn More
                  </Button>
                </Link>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <div className="rounded-full bg-green-100 p-3 w-12 h-12 flex items-center justify-center mb-4">
                  <BookOpen className="h-6 w-6 text-green-600" />
                </div>
                <CardTitle className="text-gray-900">Teach Santali</CardTitle>
                <CardDescription>Share your knowledge with learners around the world</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  If you're a fluent Santali speaker, you can help teach others through our various educational
                  programs.
                </p>
              </CardContent>
              <CardFooter>
                <Link href="/get-involved/teach" className="w-full">
                  <Button variant="outline" className="w-full bg-transparent">
                    Learn More
                  </Button>
                </Link>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <div className="rounded-full bg-green-100 p-3 w-12 h-12 flex items-center justify-center mb-4">
                  <Pencil className="h-6 w-6 text-green-600" />
                </div>
                <CardTitle className="text-gray-900">Content Creation</CardTitle>
                <CardDescription>Create learning materials and cultural resources</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  Help develop educational content, write articles, create videos, or design graphics for our resources.
                </p>
              </CardContent>
              <CardFooter>
                <Link href="/get-involved/create" className="w-full">
                  <Button variant="outline" className="w-full bg-transparent">
                    Learn More
                  </Button>
                </Link>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <div className="rounded-full bg-green-100 p-3 w-12 h-12 flex items-center justify-center mb-4">
                  <Users className="h-6 w-6 text-green-600" />
                </div>
                <CardTitle className="text-gray-900">Community Organizing</CardTitle>
                <CardDescription>Organize events and build local communities</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  Start a local chapter, organize language meetups, or host cultural events in your community.
                </p>
              </CardContent>
              <CardFooter>
                <Link href="/get-involved/organize" className="w-full">
                  <Button variant="outline" className="w-full bg-transparent">
                    Learn More
                  </Button>
                </Link>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <div className="rounded-full bg-green-100 p-3 w-12 h-12 flex items-center justify-center mb-4">
                  <Handshake className="h-6 w-6 text-green-600" />
                </div>
                <CardTitle className="text-gray-900">Partnerships</CardTitle>
                <CardDescription>Collaborate with us as an organization</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  If you represent an organization, school, or business, explore partnership opportunities with SIA.
                </p>
              </CardContent>
              <CardFooter>
                <Link href="/get-involved/partner" className="w-full">
                  <Button variant="outline" className="w-full bg-transparent">
                    Learn More
                  </Button>
                </Link>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <div className="rounded-full bg-green-100 p-3 w-12 h-12 flex items-center justify-center mb-4">
                  <Gift className="h-6 w-6 text-green-600" />
                </div>
                <CardTitle className="text-gray-900">Donate</CardTitle>
                <CardDescription>Support our mission financially</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  Your financial contribution helps fund our educational programs, resource development, and community
                  initiatives.
                </p>
              </CardContent>
              <CardFooter>
                <Link href="/donate" className="w-full">
                  <Button variant="outline" className="w-full bg-transparent">
                    Donate Now
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>

      {/* Volunteer Form CTA */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-50">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_500px]">
            <div className="flex flex-col justify-center space-y-4">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl text-gray-900">Become a Volunteer</h2>
                <p className="text-gray-600 md:text-xl">
                  Join our global network of volunteers dedicated to preserving and promoting the Santali language and
                  culture.
                </p>
                <p className="text-gray-600">
                  Whether you're a native speaker, a language enthusiast, or simply passionate about cultural
                  preservation, there's a place for you in our community.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Link href="/volunteer">
                  <Button className="bg-green-600 hover:bg-green-700">Apply Now</Button>
                </Link>
                <Link href="/volunteer-faq">
                  <Button variant="outline">Learn More</Button>
                </Link>
              </div>
            </div>
            <img
              alt="Volunteers working together"
              className="mx-auto aspect-video overflow-hidden rounded-xl object-cover object-center sm:w-full lg:order-last"
              src="/placeholder.svg?height=550&width=550"
            />
          </div>
        </div>
      </section>
    </div>
  )
}
