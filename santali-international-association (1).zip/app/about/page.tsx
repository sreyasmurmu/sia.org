import { BookOpen, Globe, Users } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-br from-green-600 to-green-700 text-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl text-gray-900">
                About Santali International Association
              </h1>
              <p className="max-w-[900px] text-white/90 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                An international community dedicated to uplifting and uniting Santali voices worldwide.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Who We Are Section */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_500px]">
            <div className="flex flex-col justify-center space-y-4">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl text-gray-900">Who We Are</h2>
                <p className="text-gray-600 md:text-xl">
                  The Santali International Association (SIA) is a global community of Santali speakers, learners,
                  educators, and cultural advocates dedicated to preserving and promoting the Santali language and
                  culture.
                </p>
                <p className="text-gray-600 md:text-xl">
                  Founded with the vision of creating a unified platform for Santali voices across the world, we work
                  tirelessly to ensure that this rich indigenous language and heritage continues to thrive in the modern
                  world.
                </p>
              </div>
            </div>
            <img
              alt="Santali community members"
              className="mx-auto aspect-video overflow-hidden rounded-xl object-cover object-center sm:w-full lg:order-last"
              src="/placeholder.svg?height=550&width=550"
            />
          </div>
        </div>
      </section>

      {/* Our Mission Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl text-gray-900">Our Mission</h2>
              <p className="max-w-[900px] text-gray-600 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                We are committed to supporting language preservation, cross-cultural communication, and educational
                outreach.
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 lg:grid-cols-3">
            <div className="flex flex-col items-center space-y-4 rounded-lg border p-6 shadow-sm">
              <div className="rounded-full bg-green-100 p-4">
                <BookOpen className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-xl font-bold">Preserve</h3>
              <p className="text-center text-gray-600">
                Document and safeguard the Santali language, ensuring its survival for future generations.
              </p>
            </div>
            <div className="flex flex-col items-center space-y-4 rounded-lg border p-6 shadow-sm">
              <div className="rounded-full bg-green-100 p-4">
                <Globe className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-xl font-bold">Promote</h3>
              <p className="text-center text-gray-600">
                Raise awareness about Santali culture and language on the global stage.
              </p>
            </div>
            <div className="flex flex-col items-center space-y-4 rounded-lg border p-6 shadow-sm">
              <div className="rounded-full bg-green-100 p-4">
                <Users className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-xl font-bold">Educate</h3>
              <p className="text-center text-gray-600">
                Create accessible learning resources and opportunities for people worldwide.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Our Team Section */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl text-gray-900">Our Team</h2>
              <p className="max-w-[900px] text-gray-600 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Meet the dedicated individuals working to preserve and promote Santali language and culture.
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl gap-6 py-12 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="flex flex-col items-center space-y-4">
                <img
                  alt={`Team member ${i}`}
                  className="aspect-square w-40 rounded-full object-cover"
                  src={`/placeholder.svg?height=160&width=160&query=person%20portrait%20${i}`}
                />
                <div className="space-y-2 text-center">
                  <h3 className="text-xl font-bold">Team Member {i}</h3>
                  <p className="text-sm text-gray-600">Position / Role</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
