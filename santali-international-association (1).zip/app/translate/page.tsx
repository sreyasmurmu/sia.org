"use client"

import { useState, useEffect } from "react"
import { ArrowDownUp, Copy, Volume2, RefreshCw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"

// Enhanced Ol Chiki to English mapping with more vocabulary
const olChikiToEnglish: { [key: string]: string } = {
  ᱥᱟᱱᱛᱟᱲᱤ: "Santali",
  ᱯᱟᱹᱨᱥᱤ: "language",
  ᱞᱟᱠᱪᱟᱨ: "culture",
  ᱫᱚᱦᱚ: "help",
  ᱞᱟᱹᱜᱤᱫ: "for",
  ᱦᱚᱲ: "people",
  ᱜᱷᱟᱨᱚᱸᱡᱽ: "family",
  ᱵᱟᱦᱟ: "flower",
  ᱫᱟᱜ: "water",
  ᱢᱤᱫ: "one",
  ᱵᱟᱨ: "two",
  ᱯᱮ: "three",
  ᱯᱩᱱ: "four",
  ᱢᱚᱬᱮ: "five",
  ᱛᱩᱨᱩᱭ: "six",
  ᱮᱭᱟᱭ: "seven",
  ᱤᱨᱟᱹᱞ: "eight",
  ᱟᱨᱮ: "nine",
  ᱜᱮᱞ: "ten",
  ᱧᱩᱛᱩᱢ: "name",
  ᱚᱲᱟᱜ: "house",
  ᱠᱟᱹᱢᱤ: "work",
  ᱥᱮᱪᱮᱫ: "education",
  ᱯᱩᱥᱴᱟᱹᱣ: "book",
  ᱡᱚᱦᱟᱨ: "hello",
  ᱵᱤᱫᱟᱹᱭ: "goodbye",
  ᱦᱮᱸ: "yes",
  ᱵᱟᱝ: "no",
  ᱫᱷᱚᱱᱭᱚᱵᱟᱫᱽ: "thank you",
  ᱢᱟᱯᱷ: "sorry",
  ᱪᱮᱫ: "what",
  ᱪᱮᱠᱟ: "who",
  ᱪᱮᱛᱟᱱ: "when",
  ᱪᱮᱛᱮ: "where",
  ᱪᱮᱞᱮᱠᱟ: "how",
  ᱪᱮᱫᱟᱜ: "why",
  ᱤᱧ: "I",
  ᱟᱢ: "you",
  ᱩᱱᱤ: "he/she",
  ᱟᱞᱮ: "we",
  ᱟᱯᱮ: "you all",
  ᱩᱱᱠᱩ: "they",
  ᱠᱚᱢ: "love",
  ᱥᱟᱱᱛᱤ: "peace",
  ᱨᱟᱹᱥᱠᱟᱹ: "joy",
  ᱵᱷᱟᱹᱜᱤ: "good",
  ᱵᱟᱹᱲᱤᱡ: "bad",
  ᱢᱟᱨᱟᱝ: "big",
  ᱦᱩᱰᱤᱧ: "small",
  ᱱᱟᱶᱟ: "new",
  ᱢᱟᱨᱮ: "old",
  ᱥᱟᱦᱟᱱ: "beautiful",
  ᱟᱨ: "and",
}

// English to Ol Chiki mapping (reverse of above)
const englishToOlChiki: { [key: string]: string } = Object.fromEntries(
  Object.entries(olChikiToEnglish).map(([key, value]) => [value.toLowerCase(), key]),
)

export default function TranslatePage() {
  const [sourceText, setSourceText] = useState("")
  const [translatedText, setTranslatedText] = useState("")
  const [sourceLanguage, setSourceLanguage] = useState("english")
  const [targetLanguage, setTargetLanguage] = useState("olchiki")
  const { toast } = useToast()

  // Real-time translation function
  const translateText = (text: string, fromLang: string, toLang: string): string => {
    if (!text.trim()) return ""

    // Split text into words while preserving spaces and punctuation
    const tokens = text.split(/(\s+|[.,!?;:])/).filter((token) => token.length > 0)
    const translatedTokens: string[] = []

    if (fromLang === "english" && toLang === "olchiki") {
      tokens.forEach((token) => {
        if (/^\s+$/.test(token) || /^[.,!?;:]+$/.test(token)) {
          // Preserve whitespace and punctuation
          translatedTokens.push(token)
        } else {
          const cleanWord = token.toLowerCase().replace(/[^\w]/g, "")
          const translation = englishToOlChiki[cleanWord]
          translatedTokens.push(translation || `[${token}]`)
        }
      })
    } else if (fromLang === "olchiki" && toLang === "english") {
      tokens.forEach((token) => {
        if (/^\s+$/.test(token) || /^[.,!?;:]+$/.test(token)) {
          // Preserve whitespace and punctuation
          translatedTokens.push(token)
        } else {
          const translation = olChikiToEnglish[token.trim()]
          translatedTokens.push(translation || `[${token}]`)
        }
      })
    } else {
      return text // Same language
    }

    return translatedTokens.join("")
  }

  // Real-time translation effect
  useEffect(() => {
    const result = translateText(sourceText, sourceLanguage, targetLanguage)
    setTranslatedText(result)
  }, [sourceText, sourceLanguage, targetLanguage])

  const handleSwapLanguages = () => {
    const tempLang = sourceLanguage
    setSourceLanguage(targetLanguage)
    setTargetLanguage(tempLang)

    const tempText = sourceText
    setSourceText(translatedText)
    setTranslatedText(tempText)
  }

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "Copied to clipboard",
      description: "Text has been copied to your clipboard.",
    })
  }

  const insertSampleText = () => {
    if (sourceLanguage === "english") {
      setSourceText("Hello, my name is John. I want to learn Santali language and culture. Thank you for helping me.")
    } else {
      setSourceText("ᱡᱚᱦᱟᱨ, ᱤᱧᱟᱜ ᱧᱩᱛᱩᱢ ᱫᱚ ᱡᱚᱦᱱ ᱠᱟᱱᱟ᱾ ᱤᱧ ᱥᱟᱱᱛᱟᱲᱤ ᱯᱟᱹᱨᱥᱤ ᱟᱨ ᱞᱟᱠᱪᱟᱨ ᱪᱮᱫᱚᱜ ᱥᱟᱱᱟᱢ ᱠᱟᱱᱟ᱾ ᱫᱷᱚᱱᱭᱚᱵᱟᱫᱽ᱾")
    }
  }

  const clearText = () => {
    setSourceText("")
    setTranslatedText("")
  }

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-br from-green-600 to-green-700 text-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">Ol Chiki Translation Tool</h1>
              <p className="max-w-[900px] text-white/90 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Real-time translation between Ol Chiki script and English with instant results as you type.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Translation Tool Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-white">
        <div className="container px-4 md:px-6">
          <Card className="max-w-4xl mx-auto border-green-200">
            <CardHeader>
              <CardTitle className="text-gray-900">Real-time Ol Chiki Translation</CardTitle>
              <CardDescription>Type in either language and see instant translation results</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex flex-col md:flex-row justify-between gap-4">
                <div className="w-full md:w-[45%]">
                  <Select value={sourceLanguage} onValueChange={setSourceLanguage}>
                    <SelectTrigger className="border-green-200">
                      <SelectValue placeholder="Select source language" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="english">English</SelectItem>
                      <SelectItem value="olchiki">Ol Chiki (ᱚᱞ ᱪᱤᱠᱤ)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-center">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={handleSwapLanguages}
                    className="border-green-200 hover:bg-green-50 bg-transparent"
                  >
                    <ArrowDownUp className="h-4 w-4 text-green-600" />
                    <span className="sr-only">Swap languages</span>
                  </Button>
                </div>

                <div className="w-full md:w-[45%]">
                  <Select value={targetLanguage} onValueChange={setTargetLanguage}>
                    <SelectTrigger className="border-green-200">
                      <SelectValue placeholder="Select target language" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="english">English</SelectItem>
                      <SelectItem value="olchiki">Ol Chiki (ᱚᱞ ᱪᱤᱠᱤ)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <label htmlFor="source-text" className="text-sm font-medium text-gray-900">
                      Source Text
                    </label>
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleCopy(sourceText)}
                        className="text-green-600 hover:bg-green-50"
                        disabled={!sourceText}
                      >
                        <Copy className="h-4 w-4 mr-1" />
                        Copy
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={insertSampleText}
                        className="text-green-600 hover:bg-green-50"
                      >
                        Sample
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={clearText}
                        className="text-red-600 hover:bg-red-50"
                        disabled={!sourceText}
                      >
                        <RefreshCw className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <Textarea
                    id="source-text"
                    placeholder={sourceLanguage === "english" ? "Type English text here..." : "ᱚᱞ ᱪᱤᱠᱤ ᱛᱮ ᱚᱞ ᱢᱮ..."}
                    className="min-h-[200px] border-green-200 focus:border-green-500 text-lg"
                    value={sourceText}
                    onChange={(e) => setSourceText(e.target.value)}
                    style={{ fontFamily: sourceLanguage === "olchiki" ? "Noto Sans Ol Chiki, serif" : "inherit" }}
                  />
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-gray-500">{sourceText.length} characters</span>
                    <Button
                      variant="outline"
                      size="sm"
                      className="bg-transparent border-green-200 text-green-600 hover:bg-green-50"
                    >
                      <Volume2 className="h-4 w-4 mr-1" />
                      Listen
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <label htmlFor="translated-text" className="text-sm font-medium text-gray-900">
                      Translated Text
                    </label>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleCopy(translatedText)}
                      className="text-green-600 hover:bg-green-50"
                      disabled={!translatedText}
                    >
                      <Copy className="h-4 w-4 mr-1" />
                      Copy
                    </Button>
                  </div>
                  <Textarea
                    id="translated-text"
                    placeholder="Translation appears here automatically..."
                    className="min-h-[200px] border-green-200 bg-green-50 text-lg"
                    value={translatedText}
                    readOnly
                    style={{ fontFamily: targetLanguage === "olchiki" ? "Noto Sans Ol Chiki, serif" : "inherit" }}
                  />
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-gray-500">{translatedText.length} characters</span>
                    <Button
                      variant="outline"
                      size="sm"
                      className="bg-transparent border-green-200 text-green-600 hover:bg-green-50"
                    >
                      <Volume2 className="h-4 w-4 mr-1" />
                      Listen
                    </Button>
                  </div>
                </div>
              </div>

              {/* Enhanced Dictionary Preview */}
              <div className="mt-6 p-4 bg-green-50 rounded-lg border border-green-200">
                <h4 className="font-semibold text-green-800 mb-2">
                  Available Vocabulary ({Object.keys(olChikiToEnglish).length} words)
                </h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm max-h-40 overflow-y-auto">
                  {Object.entries(olChikiToEnglish)
                    .slice(0, 16)
                    .map(([olchiki, english]) => (
                      <div key={olchiki} className="flex flex-col p-2 bg-white rounded border border-green-100">
                        <span
                          className="font-medium text-green-700"
                          style={{ fontFamily: "Noto Sans Ol Chiki, serif" }}
                        >
                          {olchiki}
                        </span>
                        <span className="text-gray-600 text-xs">{english}</span>
                      </div>
                    ))}
                </div>
                <p className="text-xs text-green-600 mt-2">
                  ✨ Real-time translation: Type in either language for instant results! Words not in our dictionary
                  will be shown in brackets [].
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  )
}
