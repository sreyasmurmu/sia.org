import Link from "next/link"
import { Calendar, MapPin, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function EventsPage() {
  // Sample events data
  const events = [
    {
      id: 1,
      title: "Santali Language Workshop",
      date: "August 15, 2025",
      location: "Virtual Event",
      description: "Learn the basics of Santali language in this interactive workshop led by native speakers.",
      image: "/placeholder.svg?height=300&width=600",
      attendees: 45,
    },
    {
      id: 2,
      title: "Santali Cultural Festival",
      date: "September 5-7, 2025",
      location: "New Delhi, India",
      description: "A three-day celebration of Santali culture featuring music, dance, food, and language activities.",
      image: "/placeholder.svg?height=300&width=600",
      attendees: 120,
    },
    {
      id: 3,
      title: "Santali Literature Conference",
      date: "October 12, 2025",
      location: "Kolkata, India",
      description: "Academic conference exploring the rich literary traditions of the Santali language.",
      image: "/placeholder.svg?height=300&width=600",
      attendees: 75,
    },
    {
      id: 4,
      title: "Online Santali Language Exchange",
      date: "Every Saturday",
      location: "Virtual Event",
      description: "Practice your Santali language skills with native speakers and other learners.",
      image: "/placeholder.svg?height=300&width=600",
      attendees: 30,
    },
    {
      id: 5,
      title: "Santali Film Festival",
      date: "November 20-22, 2025",
      location: "Mumbai, India",
      description: "Screening of films in Santali language with subtitles, followed by discussions with filmmakers.",
      image: "/placeholder.svg?height=300&width=600",
      attendees: 90,
    },
    {
      id: 6,
      title: "Santali Youth Leadership Summit",
      date: "December 5, 2025",
      location: "Ranchi, India",
      description: "Empowering young Santali speakers to become advocates for their language and culture.",
      image: "/placeholder.svg?height=300&width=600",
      attendees: 60,
    },
  ]

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-br from-green-600 to-green-700 text-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl text-gray-900">Events & Community</h1>
              <p className="max-w-[900px] text-white/90 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Join our global community at these upcoming events celebrating Santali language and culture.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Events Section */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {events.map((event) => (
              <Card key={event.id} className="overflow-hidden">
                <img src={event.image || "/placeholder.svg"} alt={event.title} className="w-full h-48 object-cover" />
                <CardHeader>
                  <CardTitle>{event.title}</CardTitle>
                  <CardDescription>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-green-600" />
                      <span>{event.date}</span>
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <MapPin className="h-4 w-4 text-green-600" />
                      <span>{event.location}</span>
                    </div>
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">{event.description}</p>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <div className="flex items-center text-sm text-gray-600">
                    <Users className="h-4 w-4 mr-1 text-green-600" />
                    <span>{event.attendees} attending</span>
                  </div>
                  <Link href={`/events/${event.id}`}>
                    <Button variant="outline">Learn More</Button>
                  </Link>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Host Event CTA */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl text-gray-900">Host Your Own Event</h2>
              <p className="max-w-[900px] text-gray-600 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Want to organize a Santali language or cultural event in your community? We can help!
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Link href="/host-event">
                <Button className="bg-green-600 hover:bg-green-700">Host an Event</Button>
              </Link>
              <Link href="/event-guidelines">
                <Button variant="outline">View Guidelines</Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
