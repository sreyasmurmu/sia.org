"use client"

import type React from "react"

import { useState } from "react"
import { Upload, ImageIcon, Trash2, Edit, Plus, Save } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"

interface MediaItem {
  id: string
  name: string
  url: string
  type: "image" | "video" | "audio"
  uploadDate: string
}

interface ContentItem {
  id: string
  title: string
  content: string
  type: "page" | "event" | "resource"
  lastModified: string
}

export default function AdminPage() {
  const [mediaItems, setMediaItems] = useState<MediaItem[]>([
    {
      id: "1",
      name: "sia-logo.jpg",
      url: "/images/sia-logo.jpg",
      type: "image",
      uploadDate: "2024-01-15",
    },
    {
      id: "2",
      name: "cultural-event.jpg",
      url: "/placeholder.svg?height=300&width=400",
      type: "image",
      uploadDate: "2024-01-10",
    },
  ])

  const [contentItems, setContentItems] = useState<ContentItem[]>([
    {
      id: "1",
      title: "About SIA",
      content: "The Santali International Association...",
      type: "page",
      lastModified: "2024-01-15",
    },
    {
      id: "2",
      title: "Santali Language Workshop",
      content: "Join us for an interactive workshop...",
      type: "event",
      lastModified: "2024-01-12",
    },
  ])

  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [editingContent, setEditingContent] = useState<ContentItem | null>(null)
  const [newContent, setNewContent] = useState({ title: "", content: "", type: "page" as const })
  const { toast } = useToast()

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      setSelectedFile(file)
    }
  }

  const uploadMedia = () => {
    if (!selectedFile) {
      toast({
        title: "No file selected",
        description: "Please select a file to upload.",
        variant: "destructive",
      })
      return
    }

    // In a real implementation, this would upload to a server
    const newMediaItem: MediaItem = {
      id: Date.now().toString(),
      name: selectedFile.name,
      url: URL.createObjectURL(selectedFile),
      type: selectedFile.type.startsWith("image/")
        ? "image"
        : selectedFile.type.startsWith("video/")
          ? "video"
          : "audio",
      uploadDate: new Date().toISOString().split("T")[0],
    }

    setMediaItems([...mediaItems, newMediaItem])
    setSelectedFile(null)

    toast({
      title: "Upload successful",
      description: `${selectedFile.name} has been uploaded successfully.`,
    })
  }

  const deleteMedia = (id: string) => {
    setMediaItems(mediaItems.filter((item) => item.id !== id))
    toast({
      title: "Media deleted",
      description: "The media item has been deleted successfully.",
    })
  }

  const saveContent = () => {
    if (editingContent) {
      setContentItems(
        contentItems.map((item) =>
          item.id === editingContent.id
            ? { ...editingContent, lastModified: new Date().toISOString().split("T")[0] }
            : item,
        ),
      )
      setEditingContent(null)
      toast({
        title: "Content updated",
        description: "The content has been updated successfully.",
      })
    }
  }

  const addNewContent = () => {
    if (!newContent.title || !newContent.content) {
      toast({
        title: "Missing information",
        description: "Please fill in both title and content.",
        variant: "destructive",
      })
      return
    }

    const contentItem: ContentItem = {
      id: Date.now().toString(),
      ...newContent,
      lastModified: new Date().toISOString().split("T")[0],
    }

    setContentItems([...contentItems, contentItem])
    setNewContent({ title: "", content: "", type: "page" })

    toast({
      title: "Content added",
      description: "New content has been added successfully.",
    })
  }

  const deleteContent = (id: string) => {
    setContentItems(contentItems.filter((item) => item.id !== id))
    toast({
      title: "Content deleted",
      description: "The content has been deleted successfully.",
    })
  }

  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <section className="w-full py-12 bg-gradient-to-br from-green-600 to-green-700 text-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center">
            <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">Admin Dashboard</h1>
            <p className="max-w-[900px] text-white/90 md:text-xl">Manage your website content, media, and resources.</p>
          </div>
        </div>
      </section>

      {/* Admin Content */}
      <section className="w-full py-12 bg-white">
        <div className="container px-4 md:px-6">
          <Tabs defaultValue="media" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="media">Media Management</TabsTrigger>
              <TabsTrigger value="content">Content Management</TabsTrigger>
              <TabsTrigger value="translation">Translation Dictionary</TabsTrigger>
            </TabsList>

            <TabsContent value="media" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-gray-900">Upload New Media</CardTitle>
                  <CardDescription>Upload images, videos, or audio files for your website</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid w-full max-w-sm items-center gap-1.5">
                    <Label htmlFor="media-upload">Select File</Label>
                    <Input
                      id="media-upload"
                      type="file"
                      accept="image/*,video/*,audio/*"
                      onChange={handleFileUpload}
                      className="border-green-200"
                    />
                  </div>
                  {selectedFile && (
                    <div className="flex items-center gap-2 p-2 bg-green-50 rounded border border-green-200">
                      <ImageIcon className="h-4 w-4 text-green-600" />
                      <span className="text-sm text-green-800">{selectedFile.name}</span>
                    </div>
                  )}
                  <Button onClick={uploadMedia} className="bg-green-600 hover:bg-green-700 text-white">
                    <Upload className="h-4 w-4 mr-2" />
                    Upload Media
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-gray-900">Media Library</CardTitle>
                  <CardDescription>Manage your uploaded media files</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {mediaItems.map((item) => (
                      <div key={item.id} className="border border-green-200 rounded-lg p-4 space-y-2">
                        {item.type === "image" && (
                          <img
                            src={item.url || "/placeholder.svg"}
                            alt={item.name}
                            className="w-full h-32 object-cover rounded"
                          />
                        )}
                        <div className="space-y-1">
                          <p className="font-medium text-sm text-gray-900">{item.name}</p>
                          <p className="text-xs text-gray-500">Uploaded: {item.uploadDate}</p>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="flex-1 border-green-200 text-green-600 hover:bg-green-50 bg-transparent"
                          >
                            <Edit className="h-3 w-3 mr-1" />
                            Edit
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => deleteMedia(item.id)}
                            className="border-red-200 text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="content" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-gray-900">Add New Content</CardTitle>
                  <CardDescription>Create new pages, events, or resources</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-2">
                    <Label htmlFor="new-title">Title</Label>
                    <Input
                      id="new-title"
                      value={newContent.title}
                      onChange={(e) => setNewContent({ ...newContent, title: e.target.value })}
                      className="border-green-200"
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="new-content">Content</Label>
                    <Textarea
                      id="new-content"
                      value={newContent.content}
                      onChange={(e) => setNewContent({ ...newContent, content: e.target.value })}
                      className="min-h-[150px] border-green-200"
                    />
                  </div>
                  <Button onClick={addNewContent} className="bg-green-600 hover:bg-green-700 text-white">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Content
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-gray-900">Existing Content</CardTitle>
                  <CardDescription>Edit or delete existing content</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {contentItems.map((item) => (
                      <div key={item.id} className="border border-green-200 rounded-lg p-4">
                        {editingContent?.id === item.id ? (
                          <div className="space-y-4">
                            <Input
                              value={editingContent.title}
                              onChange={(e) => setEditingContent({ ...editingContent, title: e.target.value })}
                              className="border-green-200"
                            />
                            <Textarea
                              value={editingContent.content}
                              onChange={(e) => setEditingContent({ ...editingContent, content: e.target.value })}
                              className="min-h-[100px] border-green-200"
                            />
                            <div className="flex gap-2">
                              <Button onClick={saveContent} className="bg-green-600 hover:bg-green-700 text-white">
                                <Save className="h-4 w-4 mr-2" />
                                Save
                              </Button>
                              <Button
                                variant="outline"
                                onClick={() => setEditingContent(null)}
                                className="border-gray-200"
                              >
                                Cancel
                              </Button>
                            </div>
                          </div>
                        ) : (
                          <div className="space-y-2">
                            <div className="flex justify-between items-start">
                              <div>
                                <h3 className="font-medium text-gray-900">{item.title}</h3>
                                <p className="text-sm text-gray-500">Last modified: {item.lastModified}</p>
                              </div>
                              <div className="flex gap-2">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => setEditingContent(item)}
                                  className="border-green-200 text-green-600 hover:bg-green-50"
                                >
                                  <Edit className="h-3 w-3 mr-1" />
                                  Edit
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => deleteContent(item.id)}
                                  className="border-red-200 text-red-600 hover:bg-red-50"
                                >
                                  <Trash2 className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                            <p className="text-sm text-gray-600">{item.content.substring(0, 100)}...</p>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="translation" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-gray-900">Translation Dictionary Management</CardTitle>
                  <CardDescription>Add or edit Ol Chiki to English translations</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="olchiki-word">Ol Chiki Word</Label>
                        <Input
                          id="olchiki-word"
                          placeholder="ᱥᱟᱱᱛᱟᱲᱤ"
                          className="border-green-200"
                          style={{ fontFamily: "Noto Sans Ol Chiki, serif" }}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="english-word">English Translation</Label>
                        <Input id="english-word" placeholder="Santali" className="border-green-200" />
                      </div>
                    </div>
                    <Button className="bg-green-600 hover:bg-green-700 text-white">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Translation
                    </Button>
                  </div>

                  <div className="mt-6">
                    <h4 className="font-medium text-gray-900 mb-4">Current Dictionary</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-60 overflow-y-auto">
                      {Object.entries({
                        ᱥᱟᱱᱛᱟᱲᱤ: "Santali",
                        ᱯᱟᱹᱨᱥᱤ: "language",
                        ᱞᱟᱠᱪᱟᱨ: "culture",
                        ᱫᱚᱦᱚ: "help",
                        ᱞᱟᱹᱜᱤᱫ: "for",
                        ᱦᱚᱲ: "people",
                      }).map(([olchiki, english]) => (
                        <div
                          key={olchiki}
                          className="flex justify-between items-center p-2 border border-green-200 rounded"
                        >
                          <div className="flex gap-4">
                            <span style={{ fontFamily: "Noto Sans Ol Chiki, serif" }}>{olchiki}</span>
                            <span className="text-gray-600">{english}</span>
                          </div>
                          <Button variant="ghost" size="sm" className="text-red-600 hover:bg-red-50">
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </section>
    </div>
  )
}
