"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { ArrowRight, BookOpen, Calendar, Globe, Languages, Users } from "lucide-react"
import { Button } from "@/components/ui/button"

// Enhanced Dramatic Confetti Component
const DramaticConfetti = ({ show }: { show: boolean }) => {
  if (!show) return null

  const confettiShapes = ["circle", "square", "triangle", "star"]
  const confettiColors = [
    "#22c55e",
    "#16a34a",
    "#15803d",
    "#dcfce7",
    "#bbf7d0",
    "#86efac",
    "#4ade80",
    "#fbbf24",
    "#f59e0b",
    "#d97706",
    "#fb923c",
    "#ea580c",
    "#dc2626",
    "#ef4444",
    "#8b5cf6",
    "#7c3aed",
    "#06b6d4",
    "#0891b2",
    "#ec4899",
    "#db2777",
  ]

  return (
    <>
      <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
        {/* Main confetti burst */}
        {Array.from({ length: 150 }).map((_, i) => {
          const shape = confettiShapes[Math.floor(Math.random() * confettiShapes.length)]
          const color = confettiColors[Math.floor(Math.random() * confettiColors.length)]
          const size = 8 + Math.random() * 16 // 8px to 24px
          const startX = Math.random() * 100
          const endX = startX + (Math.random() - 0.5) * 60 // More horizontal spread
          const duration = 3 + Math.random() * 4 // 3-7 seconds
          const delay = Math.random() * 2 // 0-2 second delay

          return (
            <div
              key={`main-${i}`}
              className="absolute"
              style={
                {
                  left: `${startX}%`,
                  top: "-20px",
                  animation: `dramaticFall ${duration}s ease-out ${delay}s forwards`,
                  "--end-x": `${endX}%`,
                  "--rotation": `${Math.random() * 720}deg`,
                } as any
              }
            >
              {shape === "circle" && (
                <div
                  className="rounded-full opacity-90"
                  style={{
                    width: `${size}px`,
                    height: `${size}px`,
                    backgroundColor: color,
                    boxShadow: `0 0 ${size / 2}px ${color}40`,
                  }}
                />
              )}
              {shape === "square" && (
                <div
                  className="opacity-90"
                  style={{
                    width: `${size}px`,
                    height: `${size}px`,
                    backgroundColor: color,
                    boxShadow: `0 0 ${size / 2}px ${color}40`,
                  }}
                />
              )}
              {shape === "triangle" && (
                <div
                  className="opacity-90"
                  style={{
                    width: 0,
                    height: 0,
                    borderLeft: `${size / 2}px solid transparent`,
                    borderRight: `${size / 2}px solid transparent`,
                    borderBottom: `${size}px solid ${color}`,
                    filter: `drop-shadow(0 0 ${size / 2}px ${color}40)`,
                  }}
                />
              )}
              {shape === "star" && (
                <div
                  className="opacity-90"
                  style={{
                    fontSize: `${size}px`,
                    color: color,
                    textShadow: `0 0 ${size / 2}px ${color}40`,
                  }}
                >
                  ⭐
                </div>
              )}
            </div>
          )
        })}

        {/* Side bursts */}
        {Array.from({ length: 50 }).map((_, i) => (
          <div
            key={`side-${i}`}
            className="absolute"
            style={
              {
                left: i % 2 === 0 ? "-10px" : "calc(100% + 10px)",
                top: `${20 + Math.random() * 60}%`,
                animation: `sideBurst 2s ease-out ${Math.random() * 1}s forwards`,
                "--direction": i % 2 === 0 ? "1" : "-1",
              } as any
            }
          >
            <div
              className="w-4 h-4 rounded-full opacity-80"
              style={{
                backgroundColor: confettiColors[Math.floor(Math.random() * confettiColors.length)],
              }}
            />
          </div>
        ))}

        {/* Sparkle effects */}
        {Array.from({ length: 30 }).map((_, i) => (
          <div
            key={`sparkle-${i}`}
            className="absolute animate-ping"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: "1s",
            }}
          >
            <div className="w-2 h-2 bg-yellow-400 rounded-full opacity-75" />
          </div>
        ))}
      </div>

      <style jsx>{`
        @keyframes dramaticFall {
          0% {
            transform: translateY(-100vh) translateX(0) rotate(0deg) scale(0.5);
            opacity: 1;
          }
          10% {
            transform: translateY(-80vh) translateX(calc(var(--end-x) - 50%)) rotate(36deg) scale(1);
            opacity: 1;
          }
          90% {
            transform: translateY(100vh) translateX(calc(var(--end-x) - 50%)) rotate(var(--rotation)) scale(0.8);
            opacity: 0.7;
          }
          100% {
            transform: translateY(120vh) translateX(calc(var(--end-x) - 50%)) rotate(var(--rotation)) scale(0.3);
            opacity: 0;
          }
        }

        @keyframes sideBurst {
          0% {
            transform: translateX(0) translateY(0) scale(0.5);
            opacity: 1;
          }
          50% {
            transform: translateX(calc(var(--direction) * 200px)) translateY(-100px) scale(1.2);
            opacity: 0.8;
          }
          100% {
            transform: translateX(calc(var(--direction) * 400px)) translateY(200px) scale(0.3);
            opacity: 0;
          }
        }
      `}</style>
    </>
  )
}

export default function Home() {
  const [showConfetti, setShowConfetti] = useState(false)
  const [confettiKey, setConfettiKey] = useState(0) // Key to force re-render

  useEffect(() => {
    // Show confetti every time the home page is visited
    setShowConfetti(true)
    setConfettiKey((prev) => prev + 1) // Force new confetti animation

    // Hide confetti after 6 seconds
    const timer = setTimeout(() => {
      setShowConfetti(false)
    }, 6000)

    return () => clearTimeout(timer)
  }, []) // Empty dependency array means this runs on every mount

  return (
    <div className="flex flex-col min-h-screen">
      <DramaticConfetti key={confettiKey} show={showConfetti} />

      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-br from-green-600 to-green-700 text-white relative overflow-hidden">
        {showConfetti && (
          <div className="absolute inset-0 bg-gradient-to-br from-green-500/20 to-green-800/20 animate-pulse" />
        )}
        <div className="container px-4 md:px-6 relative z-10">
          <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_500px]">
            <div className="flex flex-col justify-center space-y-4">
              <div className="flex items-center space-x-4 mb-4">
                <Image
                  src="/images/sia-logo.jpg"
                  alt="SIA Logo"
                  width={80}
                  height={80}
                  className={`rounded-full ${showConfetti ? "animate-bounce" : ""}`}
                />
                <div>
                  <h1
                    className={`text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none ${showConfetti ? "animate-pulse" : ""}`}
                  >
                    Santali International Association
                  </h1>
                  {showConfetti && (
                    <div className="mt-4 animate-bounce">
                      <span className="text-yellow-300 text-2xl font-bold drop-shadow-lg">
                        🎉✨ Welcome back to our vibrant community! ✨🎉
                      </span>
                    </div>
                  )}
                </div>
              </div>
              <div className="space-y-2">
                <p className="max-w-[600px] text-white/90 md:text-xl">
                  Preserving, promoting, and teaching the Santali language and culture on a global scale.
                </p>
                <p className="max-w-[600px] text-white/80 text-lg">ᱥᱟᱱᱛᱟᱲᱤ ᱯᱟᱹᱨᱥᱤ ᱟᱨ ᱞᱟᱠᱪᱟᱨ ᱫᱚᱦᱚ ᱞᱟᱹᱜᱤᱫ</p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Link href="/about">
                  <Button
                    className={`bg-white text-green-600 hover:bg-white/90 ${showConfetti ? "animate-pulse" : ""}`}
                  >
                    Learn More
                  </Button>
                </Link>
                <Link href="/get-involved">
                  <Button variant="outline" className="border-white text-white hover:bg-white/20 bg-transparent">
                    Get Involved
                  </Button>
                </Link>
              </div>
            </div>
            <img
              alt="Santali cultural celebration"
              className="mx-auto aspect-video overflow-hidden rounded-xl object-cover object-center sm:w-full lg:order-last"
              src="/placeholder.svg?height=550&width=550"
            />
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-gray-900">Our Mission</h2>
              <p className="max-w-[900px] text-gray-600 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                We are dedicated to supporting language preservation, cross-cultural communication, and educational
                outreach for the Santali language and culture.
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 lg:grid-cols-3">
            <div className="flex flex-col items-center space-y-4 rounded-lg border border-green-200 p-6 shadow-sm bg-green-50">
              <div className="rounded-full bg-green-100 p-4">
                <BookOpen className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">Language Preservation</h3>
              <p className="text-center text-gray-600">
                Documenting and preserving the Santali language for future generations.
              </p>
            </div>
            <div className="flex flex-col items-center space-y-4 rounded-lg border border-green-200 p-6 shadow-sm bg-green-50">
              <div className="rounded-full bg-green-100 p-4">
                <Globe className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">Cultural Exchange</h3>
              <p className="text-center text-gray-600">
                Promoting cross-cultural understanding and appreciation of Santali heritage.
              </p>
            </div>
            <div className="flex flex-col items-center space-y-4 rounded-lg border border-green-200 p-6 shadow-sm bg-green-50">
              <div className="rounded-full bg-green-100 p-4">
                <BookOpen className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">Educational Outreach</h3>
              <p className="text-center text-gray-600">
                Creating resources and opportunities for learning the Santali language.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-gray-900">Key Features</h2>
              <p className="max-w-[900px] text-gray-600 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Explore our resources designed to support both new learners and fluent speakers.
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 lg:grid-cols-2">
            <div className="flex flex-col space-y-4">
              <div className="flex items-center gap-4">
                <div className="rounded-full bg-green-100 p-3">
                  <BookOpen className="h-5 w-5 text-green-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900">Learning Resources</h3>
              </div>
              <p className="text-gray-600">
                Access pronunciation guides, grammar lessons, vocabulary lists, reading passages, and multimedia tools.
              </p>
              <Link href="/resources" className="flex items-center text-green-600 hover:underline">
                Explore Resources <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </div>
            <div className="flex flex-col space-y-4">
              <div className="flex items-center gap-4">
                <div className="rounded-full bg-green-100 p-3">
                  <Languages className="h-5 w-5 text-green-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900">Ol Chiki Translation</h3>
              </div>
              <p className="text-gray-600">
                Translate between Ol Chiki script and English to support both personal learning and professional
                projects.
              </p>
              <Link href="/translate" className="flex items-center text-green-600 hover:underline">
                Try Translation <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </div>
            <div className="flex flex-col space-y-4">
              <div className="flex items-center gap-4">
                <div className="rounded-full bg-green-100 p-3">
                  <Calendar className="h-5 w-5 text-green-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900">Community Events</h3>
              </div>
              <p className="text-gray-600">
                Join virtual and in-person events celebrating Santali language and culture around the world.
              </p>
              <Link href="/events" className="flex items-center text-green-600 hover:underline">
                View Events <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </div>
            <div className="flex flex-col space-y-4">
              <div className="flex items-center gap-4">
                <div className="rounded-full bg-green-100 p-3">
                  <Users className="h-5 w-5 text-green-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900">Get Involved</h3>
              </div>
              <p className="text-gray-600">
                Discover ways to contribute to the growing global movement to protect the Santali language.
              </p>
              <Link href="/get-involved" className="flex items-center text-green-600 hover:underline">
                Join Us <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 border-t bg-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-gray-900">
                Join Our Community
              </h2>
              <p className="max-w-[600px] text-gray-600 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Be part of the growing global movement to protect and celebrate indigenous languages like Santali.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Link href="/get-involved">
                <Button className="bg-green-600 hover:bg-green-700 text-white">Get Involved</Button>
              </Link>
              <Link href="/contact">
                <Button variant="outline" className="border-green-600 text-green-600 hover:bg-green-50 bg-transparent">
                  Contact Us
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
